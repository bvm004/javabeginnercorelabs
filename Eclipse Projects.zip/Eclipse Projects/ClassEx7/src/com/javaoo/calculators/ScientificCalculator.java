package com.javaoo.calculators;

public class ScientificCalculator {

	public static final double PI = 3.14159;
	private double holdValue;
	
	public double exp(double e) {
		return Math.exp(e);
	}
	
	public double log(double l) {
		return Math.log(l);
	}
	
	public void putValueInMemory(double v) {
		
		holdValue = v;
	}
	
	public double getValueFromMemory() {
	
		return holdValue;
		
	}
}
