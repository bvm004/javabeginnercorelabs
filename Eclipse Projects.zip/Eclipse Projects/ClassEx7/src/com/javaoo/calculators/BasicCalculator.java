package com.javaoo.calculators;



public class BasicCalculator {
	
	
	private String name;

	
	public double add(double x, double y) {
		return x+y;
	}
	
	public double subtract(double w, double s) {
		return w-s;
	}
	
	public double multiply(double b, double a)
	{
		return a*b;
	}
	
	public double divide(double d, double f) {
		return d / f;
	}
}
