package com.javaoo.calculators;

public class TrigonometricCalculator {

	public static double sine(double s) {
		
		return Math.sin(s);
	}
	
	public static double cosine(double c) {
		 return Math.cos(c);
	}
	
	public static double tangent(double t) {
		return Math.tan(t);
	}
	
	public static double arcsine(double as) {
		return Math.asin(as);
	}
	
	public static double arccosine(double ac) {
		return Math.acos(ac);
		
	}
	
	public double arctangent(double at) {
		return Math.atan(at);
	}
	
	
	
	
	
}
