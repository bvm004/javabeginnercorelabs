package com.javaoo.calculators;

public class CalculatorDriver {

	public static void main(String[] args) {
		
		//TrigonometricCalculator calc = new TrigonometricCalculator();
		//double r = calc.cosine(30);
		
		double r = TrigonometricCalculator.cosine(45);
		
		System.out.println(r);
		
	}

}
