package com.lq.ex;

public class Main {

	public static void main(String[] args) {
		

			//Box box1 = new Box(10, 25, 30);
			//box1.printBox();

			//Box box2 = new Box(20);
			//box2.printBox();

			Box box3 = new Box(0,9,2.5);
			box3.printBox();
			
		
	}

}
