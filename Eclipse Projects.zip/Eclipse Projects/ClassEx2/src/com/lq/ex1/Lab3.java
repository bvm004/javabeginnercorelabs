package com.lq.ex1;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*String[] daysOfWeek = { "Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"};
		System.out.println("Days of the week are: ");
		
		for (int i = 0; i<7; i++)
		{
			System.out.println(daysOfWeek[i]);
		}
		
		for ( int i = 6; i>=0; i--)
		{
			System.out.println(daysOfWeek[i]);
		}
		*/
		/*
		int a = 4;
		int b = 20;
		int c = 30;
		
		if ( a > 5 && b > 10 || c>20 )
		{
		System.out.println(" Hello ");
		
		}else {
			System.out.println("Bye");
		}
		*/
		/*
		int a = 8;
		if ( a % 2 == 0 )
		{
			System.out.println("Even");
		}else
		{
			System.out.println("Odd");
			
		}
		*/
		/*
		for(int i = 1; i<=100; i++)
		{
			//System.out.println(i);
			if (i <50 || i>60)
			{
				System.out.println(i);
			}
		}
		*/
		/*
		for( int i = 1; i <=50; i++)
		{
			
			if (i % 2 == 0)
			{
				System.out.println(i +" Even");
			}else
			{
				System.out.println(i + " Odd");
			}
		}
		*/
		/*
		int n = 20;
		int count = 0;
		
		while (count<n)
		{
			System.out.print("*");
			count++;
		}
		*/
		/*
		int k = 0;
		while (k <=20)
		{
			k++;
			if ( k%2!=0)
			{
				continue;
			}
			System.out.println(k);
		}
		
		
		int n = 20;
		int count = 30;
		do {
			System.out.println("+");
			count++;
		} while (count <n);
		*/
		/*
		int a = 6;
		if (a == 1)
		{
			System.out.println("A");
		}else if (a == 2) {
			System.out.println("B");
		}else if (a == 3) {
			System.out.println("C");
		}else if (a == 4) {
			System.out.println("D");
		}else {
			System.out.println("Other");
		}
		*/
		/*
		int a = 3;
		
		switch(a) {
		case 1:
			System.out.println("A");
			break;
		case 2:
			System.out.println("B");
			break;
		case 3:
			System.out.println("C");
			break;
		case 4: 
			System.out.println("D");
			break;
			
			default:
				System.out.println("Other");
				break;
		
		}
		*/

		/*
		int m = 1;
		while( m <= 12) {
			String monthName = "";
			int numberOfDays= 0;
			
			switch(m) {
			case 1:
				monthName = "Jan";
				numberOfDays = 31;
				break;
			case 2:
				monthName = "Feb";
				numberOfDays = 28;
				break;
			case 3:
				monthName = "Mar";
				numberOfDays = 31;
				break;
			case 4:
				monthName = "Apr";
				numberOfDays = 30;
				break;
			case 5:
				monthName = "May";
				numberOfDays = 31;
				break;
			case 6:
				monthName = "Jun";
				numberOfDays = 30;
				break;
			case 7:
				monthName = "Jul";
				numberOfDays = 31;
				break;
			case 8:
				monthName = "Aug";
				numberOfDays= 31;
				break;
			case 9:
				monthName = "Sep";
				numberOfDays = 30;
				break;
			case 10:
				monthName = "Oct";
				numberOfDays = 31;
				break;
			case 11:
				monthName = "Nov";
				numberOfDays = 30;
				break;
			case 12:
				monthName = "Dec";
				numberOfDays = 31;
				break;
			}
			
			System.out.println(monthName + " has " + numberOfDays + " days." );
			
			m++;
			
			} */
		
		
		
		}
		
		
	}

