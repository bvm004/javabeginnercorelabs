package com.lq.model;

public class Employee {

	public void b() {
		
		User op = new User("Jane", "Doe");
		
		op.getFirstName();
	}
	
	
	
	
}
