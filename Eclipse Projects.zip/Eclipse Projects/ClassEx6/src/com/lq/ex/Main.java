package com.lq.ex;

import com.lq.model.User;




public class Main {

	public static void main(String[] args) {
		
	
		User a = new User("John", "Doe");
		
		
		com.lq.view.User b = new com.lq.view.User("Ryan");
		
		
		String f = a.getFirstName();
		
		

	}

}
