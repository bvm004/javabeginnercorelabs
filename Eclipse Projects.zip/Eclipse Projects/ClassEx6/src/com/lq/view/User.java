package com.lq.view;

public class User {

	private String fatherName;
	
	

	public User(String fatherName) {
		setFatherName(fatherName);
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	
	
	
}
