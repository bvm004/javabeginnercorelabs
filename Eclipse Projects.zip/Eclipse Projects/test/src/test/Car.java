package test;

public class Car {

}
