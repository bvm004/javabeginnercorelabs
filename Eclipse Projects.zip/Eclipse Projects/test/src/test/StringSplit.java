package test;

public class StringSplit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "I love Java more than Python";
		System.out.println("S : " + s1);
		
		String[] words = s1.split(" ");
		System.out.println("words : " + words);
		
		for (String w : words) {
			System.out.println(w);
		}
	}

}
