package com.lq.ex;

public class Main {

	public static void main(String[] args) {
		
//		Car car1 = new Car();
//		car1.setSpeed(50);
//		System.out.println("car :" + car1);
		
		SportsCar sports1 = new SportsCar();
		System.out.println("sports1 :" + sports1);
		sports1.setSpeed(50);
		System.out.println("sports1 : " + sports1);
		
		Car sports2 = new SportsCar();
		System.out.println("sports2 : " + sports2);
		
		Object sports3 = new SportsCar();
		System.out.println("sports3 : " + sports3);
		
		StationWagon wagon1 = new StationWagon();
		System.out.println("wagon1 : " + wagon1);
		
		Car wagon2 = new StationWagon();
		wagon2.setSpeed(50);
		System.out.println("wagon2 : " + wagon2);
		
	}

	
	/*getCarInventory() {
		Car [] carsInventory = [
		      new StationWagon(),                  
		      new StationWagon(),
		      new SportsCar(),
		      new SportsCar()  
		    ];
			
		return carsInventory;
	}
	
	printInventory() {
		Car [] cars = getInventory();
		for (Car c : cars) {
			System.out.println(c);
		}
	}
	
	printInventory2() {
		StationWagon [] = getStationWagons();
		//print
		
		SportsCar [] = getSportsCar();
		//print
		
	}
	*/
	
	
}
