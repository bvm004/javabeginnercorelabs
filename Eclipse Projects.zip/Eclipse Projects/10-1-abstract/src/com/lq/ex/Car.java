package com.lq.ex;

public abstract class Car {

	int speed;
	
//	public void setSpeed(int speed) {
//		this.speed = speed;
//	}

	abstract public void setSpeed(int speed);
	
	@Override
	public String toString() {
		return "Car [speed=" + speed + "]";
	}
	
	
	
}
