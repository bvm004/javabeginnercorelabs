package com.lq.ex;

public class SportsCar extends Car {

	public SportsCar() {
		super();
		this.speed = 100;
	}
	
	@Override
	public String toString() {
		return "SportsCar [zoom=" + speed + "]";
	}

	@Override
	public void setSpeed(int speed) {
		this.speed = speed + 20;
		
	}

	
	
	
}
