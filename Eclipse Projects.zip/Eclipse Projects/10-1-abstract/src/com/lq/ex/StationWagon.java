package com.lq.ex;

public class StationWagon extends Car {

	public StationWagon() {
		this.speed = 0;
	}
	
	@Override
	public void setSpeed(int speed) {
		// TODO Auto-generated method stub

	}

	@Override
	public String toString() {
		return "StationWagon [speed=" + speed + "]";
	}

	
}
