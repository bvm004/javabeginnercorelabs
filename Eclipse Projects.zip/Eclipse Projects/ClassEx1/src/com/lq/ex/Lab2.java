package com.lq.ex;
public class Lab2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	int a = 10;
		int b = 20;
		int c=30; int d = 40;
		int r = a + b;
		*/
		
		/*
		float a = 4.178F;
		float b = 9.745f;
		int c = 1;
		float r = (int) a + c * b;
		System.out.println("Result is: " + r);
		*/
		
		/*
		String a = "Hello";
		String b = "World";
		System.out.println(a + b);
		*/
		/*
		int[] myIntArray = new int[5];
		myIntArray[0] =  10;
		myIntArray[1] = 26;
		myIntArray[2] = 48;
		*/
		
		int[] daysInMonths = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		
		String[] monthNames= {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
		
		for (int i = 0; i<12; i++ )
		{
			System.out.println(monthNames[i] + " has " + daysInMonths[i] + " days");
		}
		/*
		System.out.println( monthNames[0] + " has " + daysInMonths[0] + " days");
		System.out.println( monthNames[1] + " has " + daysInMonths[1] + " days");
		System.out.println( monthNames[2] + " has " + daysInMonths[2] + " days");
		System.out.println( monthNames[3] + " has " + daysInMonths[3] + " days");
		System.out.println( monthNames[4] + " has " + daysInMonths[4] + " days");
		System.out.println( monthNames[5] + " has " + daysInMonths[5] + " days");
		System.out.println( monthNames[6] + " has " + daysInMonths[6] + " days");
		System.out.println( monthNames[7] + " has " + daysInMonths[7] + " days");
		System.out.println( monthNames[8] + " has " + daysInMonths[8] + " days");
		System.out.println( monthNames[9] + " has " + daysInMonths[9] + " days");
		System.out.println( monthNames[10] + " has " + daysInMonths[10] + " days");
		System.out.println( monthNames[11] + " has " + daysInMonths[11] + " days");
		*/
	}

}
