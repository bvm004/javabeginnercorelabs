package com.lq.ex;




/**
 * Here is our main class that we're writing a doc for
 * 
 * 
 * @author Leer
 *
 */

public class BasicCalculator {
	
	/**
	 * Full name of a person
	 */
	private String name;
	
	/**
	 * 
	 * @param x The first number
	 * @param y The second number
	 * @return Sum of two provided numbers
	 * @see <a href="https://google.com"> Ticket #24</a>
	 */

	
	public double add(double x, double y) {
		return x+y;
	}
	
	public double subtract(double w, double s) {
		return w-s;
	}
	
	public double multiply(double b, double a)
	{
		return a*b;
	}
	
	public double divide(double d, double f) {
		return d / f;
	}
}
