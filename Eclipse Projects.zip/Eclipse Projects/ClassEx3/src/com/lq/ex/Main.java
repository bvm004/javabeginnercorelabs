package com.lq.ex;

public class Main {

	public static void main(String[] args) {
		/*
		Car toyota = new Car();
		
		Car honda = new Car();
		
		
		honda.setSpeed(95);
		
		toyota.setSpeed(65);
		
		toyota.setGas(3);
		
		int temp;
		
		temp = toyota.getSpeed();
		
		System.out.println( temp );
		System.out.println( toyota.getGas() );
		
		
		int temp2;
		
		temp2 = honda.getSpeed();
		
		System.out.println( temp2 );
		*/
		/*
		Employee emp1 = new Employee("John", "Doe", "789-45-12-7", 15000);
		
		Employee emp2 = new Employee("Jane", "Doe", "456-89-14-6");
		
		Employee emp3 = new Employee("Ryan", "Doe");
		*/
		
		//Box box1 = new Box(10,25,30);
		//box1.printBox();
		
		//Box box2 = new Box(0,0,0);
		//box2.printBox();
		
		
	}

}
