package com.lq.ex;

public class Car {

	
	private int speed;
	
	private boolean engineState;
	
	private int gas;
	
	public void setSpeed( int sp) {
		speed = sp;
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void setGas( int gas) {
		
		this.gas = gas;
	}
	
	public int getGas() {
		
		return gas;
	}
	
	
	
	
	
}
