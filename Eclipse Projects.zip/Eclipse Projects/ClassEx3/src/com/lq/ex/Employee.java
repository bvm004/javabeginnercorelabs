package com.lq.ex;

public class Employee {

	private String firstName;
	private String lastName;
	private String ssn;
	private int salary;
	
	public Employee( String fn, String ln, String ssn, int salary ) {
		this(fn,ln,ssn);
		setSalary(salary);
	}
	
	public Employee( String fn, String ln, String ssn ) {
		this(fn,ln);
		setSsn(ssn);
		
	}
	public Employee( String fn, String ln ) {
		setFirstName(fn);
		setLastName(ln);
		
	}

	
	
	public final String getFirstName() {
		return firstName;
	}

	public final void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public final String getLastName() {
		return lastName;
	}

	public final void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public final String getSsn() {
		return ssn;
	}

	public final void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public final int getSalary() {
		return salary;
	}

	public final void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	
	
	
	
	
}
