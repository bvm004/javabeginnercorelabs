package amazon;

public class Main {

	public static void main(String[] args) {
		
/*		Book book1 = new Book ("Harry Potter", "JK Rowling", 10);
		Book book2 = new Book ("Hitchhiker's Guide", "Douglas Adams", 12);
		
		System.out.println("book1: " + book1);
		System.out.println("book2: "+ book2);
		
		Computer com1 = new Computer ("8-core", "32-GB", "1TB", 1000);
		System.out.println("com1: " + com1);
*/
		Item [] items = getInventory();
		for (Item i : items) {
			System.out.println(i.getDescription() + ", sale price: " + i.getPrice());
		}
		
	}

	static public Item[] getInventory () {
		Item[] items = new Item [] {
				new Book ("Harry Potter", "JK Rowling", 10),
				new Book ("Hitchhiker's Guide", "Douglas Adams", 12),
				new Computer ("8-core", "32-GB", "1TB", 1000),
				new Computer ("16-core", "64-GB", "2TB", 1500),
				new Camera (300, "Cannon"),
				new Camera (500, "Nikon"),
				new Book ("Jane Eyre", "Charlotte Bront�", 15)
		};
		
		return items;
		
	}
	
}
