Models

-Item (price)
	-Book ( title, author)
	-Computer ( cpu, memory, disk)
	-Camera (make)