package com.lq.ex;

public class Main {

	public static void main(String[] args) {
		Box box1 = new Box (10.0, 20.0, 30.0);
		System.out.println("box1 : " + box1); // box1.toString()
		
		
		Cube cube1 = new Cube (15.0);
		System.out.println("cube1 : " + cube1);

	}

}
