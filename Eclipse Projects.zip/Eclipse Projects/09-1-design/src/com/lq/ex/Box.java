package com.lq.ex;

public class Box {
	double length, width,height;

	public Box(double length, double width, double height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;	
	}
	
	
	//effective java - item 12
	@Override
	public String toString() {
		return "Box [length=" + length + ", width=" + width + ", height=" + height + "]";
	}
	
	

	
	
	
	
	
}
