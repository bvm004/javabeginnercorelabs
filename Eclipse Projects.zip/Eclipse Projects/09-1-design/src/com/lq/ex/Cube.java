package com.lq.ex;

public class Cube extends Box {

	public Cube(double size) {
		super(size,size,size);
		
	}

	@Override
	public String toString() {
		return "Cube [size=" + length + "]";
	}
	
	
	
	
}
