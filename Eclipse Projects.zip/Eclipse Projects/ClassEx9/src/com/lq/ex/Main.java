package com.lq.ex;

public class Main {

	public static void main(String[] args) {
		
		int a = 19 ;
		
		int b;
		
		b = (a<=10)? 48 : 65;
		
		/*if(a > 10) {
			b = 80;
		}else {
			b = 60;
		}
		*/
		System.out.println(b);
		

	}

}
